import React from 'react';
import { List, Checkbox } from 'antd';

const TodoItem = ({ todo, index, toggleTodo }) => {
  return (
    <List.Item>
      <Checkbox checked={todo.completed} onChange={() => toggleTodo(index)}>
        <span style={{ textDecoration: todo.completed ? 'line-through' : 'none' }}>
          {todo.text}
        </span>
      </Checkbox>
    </List.Item>
  );
};

export default TodoItem;


