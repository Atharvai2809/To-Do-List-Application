import React, { useState } from 'react';
import { Input, Button, List } from 'antd';
import TodoItem from './TodoItem';

const TodoList = () => {
  const [todos, setTodos] = useState([]);
  const [inputValue, setInputValue] = useState('');

  const addTodo = () => {
    if (inputValue.trim()) {
      setTodos([...todos, { text: inputValue, completed: false }]);
      setInputValue('');
    }
  };

  const toggleTodo = (index) => {
    const newTodos = todos.map((todo, idx) => {
      if (idx === index) {
        return { ...todo, completed: !todo.completed };
      }
      return todo;
    });
    setTodos(newTodos);
  };

  return (
    <div style={{ padding: '20px' }}>
      <Input
        placeholder="Add a new task"
        value={inputValue}
        onChange={(e) => setInputValue(e.target.value)}
        onPressEnter={addTodo}
        style={{ marginBottom: '10px' }}
      />
      <Button type="primary" onClick={addTodo} style={{ marginBottom: '20px' }}>
        Add Task
      </Button>
      <List
        bordered
        dataSource={todos}
        renderItem={(todo, index) => (
          <TodoItem todo={todo} index={index} toggleTodo={toggleTodo} />
        )}
      />
    </div>
  );
};

export default TodoList;