import React from 'react';
import 'antd/dist/antd.css';
import TodoList from './components/TodoList';

const App = () => {
  return (
    <div className="App">
      <h1>To do List</h1>
      <TodoList />
    </div>
  );
};

export default App;
